package com.example.biodatalingling

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val tvResult = findViewById<TextView>(R.id.tvResult)

        // Ambil data dari intent
        val nama = intent.getStringExtra("nama")
        val alamat = intent.getStringExtra("alamat")
        val tglLahir = intent.getStringExtra("tanggal")
        val gender = intent.getStringExtra("gender")
        val agama = intent.getStringExtra("agama")

        val hasil = """
            Nama Lengkap : $nama
            Alamat       : $alamat
            Tanggal Lahir: $tglLahir
            Jenis Kelamin: $gender
            Agama        : $agama
        """.trimIndent()

        tvResult.text = hasil
    }
}